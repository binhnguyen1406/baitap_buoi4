﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace RadixUnitTest
{
    [TestClass]
    public class RadixTests
    {

        public class Radix
        {
            private int number;

            public Radix(int number)
            {
                if (number < 0)
                    throw new ArgumentException("Incorrect Value");

                this.number = number;
            }

            public string ConvertDecimalToAnother(int radix = 2)
            {
                int n = this.number;

                if (radix < 2 || radix > 16)
                    throw new ArgumentException("Invalid Radix");

                List<string> result = new List<string>();
                while (n > 0)
                {
                    int value = n % radix;
                    if (value < 10)
                        result.Add(value.ToString());
                    else
                    {
                        switch (value)
                        {
                            case 10: result.Add("A"); break;
                            case 11: result.Add("B"); break;
                            case 12: result.Add("C"); break;
                            case 13: result.Add("D"); break;
                            case 14: result.Add("E"); break;
                            case 15: result.Add("F"); break;
                        }
                    }
                    n /= radix;
                }
                result.Reverse();
                return string.Join("", result.ToArray());
            }
        }


        [TestMethod]
        public void TC01_He_2()
        {
            var r = new Radix(10);
            Assert.AreEqual("1010", r.ConvertDecimalToAnother(2));
        }

        [TestMethod]
        public void TC02_He_16_Mot_Chu_So()
        {
            var r = new Radix(15);
            Assert.AreEqual("F", r.ConvertDecimalToAnother(16));
        }

        [TestMethod]
        public void TC03_He_16_Nhieu_Chu_So()
        {
            var r = new Radix(255);
            Assert.AreEqual("FF", r.ConvertDecimalToAnother(16));
        }

        [TestMethod]
        public void TC04_He_8()
        {
            var r = new Radix(8);
            Assert.AreEqual("10", r.ConvertDecimalToAnother(8));
        }

        [TestMethod]
        public void TC05_Number_Am()
        {
            Assert.ThrowsException<ArgumentException>(() =>
            {
                new Radix(-5);
            });
        }

        [TestMethod]
        public void TC06_Radix_Khong_Hop_Le()
        {
            var r = new Radix(10);
            Assert.ThrowsException<ArgumentException>(() =>
            {
                r.ConvertDecimalToAnother(1);
            });
        }
    }
}
