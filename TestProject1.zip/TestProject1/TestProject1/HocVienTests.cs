﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace HocVienUnitTest
{
    [TestClass]
    public class HocVienTests
    {
        public class HocVien
        {
            public string MaHV { get; set; }
            public string HoTen { get; set; }
            public string QueQuan { get; set; }
            public double Diem1 { get; set; }
            public double Diem2 { get; set; }
            public double Diem3 { get; set; }

            public HocVien(string ma, string ten, string que, double d1, double d2, double d3)
            {
                MaHV = ma;
                HoTen = ten;
                QueQuan = que;
                Diem1 = d1;
                Diem2 = d2;
                Diem3 = d3;
            }

            public double DiemTrungBinh()
            {
                return (Diem1 + Diem2 + Diem3) / 3;
            }

            public bool DuDieuKienHocBong()
            {
                return DiemTrungBinh() >= 8.0
                       && Diem1 >= 5
                       && Diem2 >= 5
                       && Diem3 >= 5;
            }
        }


        [TestMethod]
        public void TC01_Du_Dieu_Kien_Hoc_Bong()
        {
            var hv = new HocVien("HV01", "An", "HN", 8.5, 8.0, 9.0);
            Assert.IsTrue(hv.DuDieuKienHocBong());
        }

        [TestMethod]
        public void TC02_Diem_TB_Nho_Hon_8()
        {
            var hv = new HocVien("HV02", "Binh", "HP", 7.0, 7.0, 9.0);
            Assert.IsFalse(hv.DuDieuKienHocBong());
        }

        [TestMethod]
        public void TC03_Co_Mon_Duoi_5()
        {
            var hv = new HocVien("HV03", "Cuong", "DN", 9.0, 4.5, 9.0);
            Assert.IsFalse(hv.DuDieuKienHocBong());
        }

        [TestMethod]
        public void TC04_Diem_TB_Bang_8()
        {
            var hv = new HocVien("HV04", "Dung", "HCM", 8.0, 8.0, 8.0);
            Assert.IsTrue(hv.DuDieuKienHocBong());
        }

        [TestMethod]
        public void TC05_Mon_Bang_5()
        {
            var hv = new HocVien("HV05", "Huy", "CT", 9.0, 5.0, 10.0);
            Assert.IsTrue(hv.DuDieuKienHocBong());
        }
    }
}
