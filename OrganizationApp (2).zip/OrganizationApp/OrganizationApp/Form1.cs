﻿using System;
using System.Windows.Forms;
using OrganizationApp.Models;
using OrganizationApp.Services;

namespace OrganizationApp
{
    public partial class Form1 : Form
    {
        private readonly OrganizationService organizationService;
        private Organization currentOrganization;

        public Form1()
        {
            InitializeComponent();

            organizationService = new OrganizationService();

            btnSave.Click += BtnSave_Click;
            btnBack.Click += BtnBack_Click;
            btnDirector.Click += BtnDirector_Click;

            btnDirector.Enabled = false;
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            try
            {
                // ===== VALIDATE =====
                if (string.IsNullOrWhiteSpace(txtOrgName.Text))
                {
                    MessageBox.Show("Organization Name is required");
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtPhoneNumber.Text))
                {
                    MessageBox.Show("Phone Number is required");
                    return;
                }

                // ===== TẠO ORGANIZATION (CHỈ DÙNG FIELD TỒN TẠI) =====
                var org = new Organization
                {
                    OrgName = txtOrgName.Text.Trim(),
                    Address = txtAddressLine1.Text.Trim(),
                    Phone = txtPhoneNumber.Text.Trim(),
                    Email = txtEmail.Text.Trim(),
                    CreatedAt = DateTime.Now
                };

                // ===== SAVE =====
                organizationService.Save(org);

                currentOrganization = org;

                MessageBox.Show(
                    "Save successfully",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

                // ✅ BẬT NÚT DIRECTOR
                btnDirector.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void BtnDirector_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Director Management will be implemented later",
                "Info",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
