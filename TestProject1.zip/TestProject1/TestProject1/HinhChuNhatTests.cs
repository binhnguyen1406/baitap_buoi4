﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace RectangleUnitTest
{
    [TestClass]
    public class HinhChuNhatTests
    {

        public class Diem
        {
            public int X { get; set; }
            public int Y { get; set; }

            public Diem(int x, int y)
            {
                X = x;
                Y = y;
            }
        }

        public class HinhChuNhat
        {
            private Diem topLeft;
            private Diem bottomRight;

            public HinhChuNhat(Diem topLeft, Diem bottomRight)
            {
                this.topLeft = topLeft;
                this.bottomRight = bottomRight;
            }

            public int DienTich()
            {
                int width = bottomRight.X - topLeft.X;
                int height = topLeft.Y - bottomRight.Y;
                if (width < 0 || height < 0) return 0;
                return width * height;
            }

            public bool GiaoNhau(HinhChuNhat other)
            {
                if (this.bottomRight.X <= other.topLeft.X ||
                    this.topLeft.X >= other.bottomRight.X ||
                    this.bottomRight.Y >= other.topLeft.Y ||
                    this.topLeft.Y <= other.bottomRight.Y)
                    return false;

                return true;
            }
        }

        [TestMethod]
        public void TC01_Tinh_Dien_Tich()
        {
            var rect = new HinhChuNhat(
                new Diem(0, 4),
                new Diem(5, 0)
            );
            Assert.AreEqual(20, rect.DienTich());
        }

        [TestMethod]
        public void TC02_Dien_Tich_Bang_0()
        {
            var rect = new HinhChuNhat(
                new Diem(0, 0),
                new Diem(0, 0)
            );
            Assert.AreEqual(0, rect.DienTich());
        }

        [TestMethod]
        public void TC03_Hai_HCN_Giao_Nhau()
        {
            var r1 = new HinhChuNhat(
                new Diem(0, 4),
                new Diem(4, 0)
            );
            var r2 = new HinhChuNhat(
                new Diem(2, 3),
                new Diem(6, 1)
            );
            Assert.IsTrue(r1.GiaoNhau(r2));
        }

        [TestMethod]
        public void TC04_Hai_HCN_Khong_Giao()
        {
            var r1 = new HinhChuNhat(
                new Diem(0, 4),
                new Diem(4, 0)
            );
            var r2 = new HinhChuNhat(
                new Diem(5, 3),
                new Diem(7, 1)
            );
            Assert.IsFalse(r1.GiaoNhau(r2));
        }

        [TestMethod]
        public void TC05_Hai_HCN_Cham_Bien()
        {
            var r1 = new HinhChuNhat(
                new Diem(0, 4),
                new Diem(4, 0)
            );
            var r2 = new HinhChuNhat(
                new Diem(4, 3),
                new Diem(6, 1)
            );
            Assert.IsFalse(r1.GiaoNhau(r2));
        }
    }
}
