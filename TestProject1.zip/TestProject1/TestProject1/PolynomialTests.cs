﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;

namespace PolynomialUnitTest
{
    [TestClass]
    public class PolynomialTests
    {
        class Polynomial
        {
            private int n;
            private List<int> a;

            public Polynomial(int n, List<int> a)
            {
                if (n < 0 || a.Count != n + 1)
                    throw new ArgumentException("Invalid Data");

                this.n = n;
                this.a = a;
            }

            public int Cal(double x)
            {
                int result = 0;
                for (int i = 0; i <= this.n; i++)
                {
                    result += (int)(a[i] * Math.Pow(x, i));
                }
                return result;
            }
        }


        [TestMethod]
        public void TC01_DaThuc_Bac_2()
        {
            var poly = new Polynomial(2, new List<int> { 1, 2, 3 });
            int result = poly.Cal(2);
            Assert.AreEqual(17, result); // 1 + 2*2 + 3*4
        }

        [TestMethod]
        public void TC02_DaThuc_Bac_0()
        {
            var poly = new Polynomial(0, new List<int> { 5 });
            int result = poly.Cal(10);
            Assert.AreEqual(5, result);
        }

        [TestMethod]
        public void TC03_Thieu_He_So()
        {
            Assert.ThrowsException<ArgumentException>(() =>
            {
                new Polynomial(2, new List<int> { 1, 2 });
            });
        }

        [TestMethod]
        public void TC04_Du_He_So()
        {
            Assert.ThrowsException<ArgumentException>(() =>
            {
                new Polynomial(1, new List<int> { 1, 2, 3 });
            });
        }

        [TestMethod]
        public void TC05_N_Am()
        {
            Assert.ThrowsException<ArgumentException>(() =>
            {
                new Polynomial(-1, new List<int> { 1 });
            });
        }
    }
}
