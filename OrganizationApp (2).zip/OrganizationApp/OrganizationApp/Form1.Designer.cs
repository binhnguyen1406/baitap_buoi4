﻿namespace OrganizationApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();

            // Left Column
            this.lblOrgName = new System.Windows.Forms.Label();
            this.txtOrgName = new System.Windows.Forms.TextBox();
            this.lblOrgShortDesc = new System.Windows.Forms.Label();
            this.txtOrgShortDesc = new System.Windows.Forms.TextBox();
            this.lblLeadContact = new System.Windows.Forms.Label();
            this.txtLeadContact = new System.Windows.Forms.TextBox();
            this.linkLookup1 = new System.Windows.Forms.LinkLabel();
            this.lblAddressLine1 = new System.Windows.Forms.Label();
            this.txtAddressLine1 = new System.Windows.Forms.TextBox();
            this.lblAddressLine2 = new System.Windows.Forms.Label();
            this.txtAddressLine2 = new System.Windows.Forms.TextBox();
            this.lblAddressLine3 = new System.Windows.Forms.Label();
            this.txtAddressLine3 = new System.Windows.Forms.TextBox();
            this.lblPostcode = new System.Windows.Forms.Label();
            this.txtPostcode = new System.Windows.Forms.TextBox();
            this.linkLookup2 = new System.Windows.Forms.LinkLabel();
            this.lblCityTown = new System.Windows.Forms.Label();
            this.txtCityTown = new System.Windows.Forms.TextBox();
            this.lblCounty = new System.Windows.Forms.Label();
            this.txtCounty = new System.Windows.Forms.TextBox();

            // Right Column
            this.lblPrefOrg = new System.Windows.Forms.Label();
            this.chkPrefOrg = new System.Windows.Forms.CheckBox();
            this.lblExpression = new System.Windows.Forms.Label();
            this.chkExpression = new System.Windows.Forms.CheckBox();
            this.lblTypeOfBusiness = new System.Windows.Forms.Label();
            this.txtTypeOfBusiness = new System.Windows.Forms.TextBox();
            this.linkLookup3 = new System.Windows.Forms.LinkLabel();
            this.lblSICCode = new System.Windows.Forms.Label();
            this.txtSICCode = new System.Windows.Forms.TextBox();
            this.lblOrgFullDesc = new System.Windows.Forms.Label();
            this.txtOrgFullDesc = new System.Windows.Forms.TextBox();
            this.lblPhoneNumber = new System.Windows.Forms.Label();
            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
            this.lblFax = new System.Windows.Forms.Label();
            this.txtFax = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblWebAddress = new System.Windows.Forms.Label();
            this.txtWebAddress = new System.Windows.Forms.TextBox();

            // Buttons
            this.btnSave = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnDirector = new System.Windows.Forms.Button();

            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();

            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(12, 41);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(820, 480);
            this.tabControl1.TabIndex = 0;

            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lblOrgName);
            this.tabPage1.Controls.Add(this.txtOrgName);
            this.tabPage1.Controls.Add(this.lblOrgShortDesc);
            this.tabPage1.Controls.Add(this.txtOrgShortDesc);
            this.tabPage1.Controls.Add(this.lblLeadContact);
            this.tabPage1.Controls.Add(this.txtLeadContact);
            this.tabPage1.Controls.Add(this.linkLookup1);
            this.tabPage1.Controls.Add(this.lblAddressLine1);
            this.tabPage1.Controls.Add(this.txtAddressLine1);
            this.tabPage1.Controls.Add(this.lblAddressLine2);
            this.tabPage1.Controls.Add(this.txtAddressLine2);
            this.tabPage1.Controls.Add(this.lblAddressLine3);
            this.tabPage1.Controls.Add(this.txtAddressLine3);
            this.tabPage1.Controls.Add(this.lblPostcode);
            this.tabPage1.Controls.Add(this.txtPostcode);
            this.tabPage1.Controls.Add(this.linkLookup2);
            this.tabPage1.Controls.Add(this.lblCityTown);
            this.tabPage1.Controls.Add(this.txtCityTown);
            this.tabPage1.Controls.Add(this.lblCounty);
            this.tabPage1.Controls.Add(this.txtCounty);
            this.tabPage1.Controls.Add(this.lblPrefOrg);
            this.tabPage1.Controls.Add(this.chkPrefOrg);
            this.tabPage1.Controls.Add(this.lblExpression);
            this.tabPage1.Controls.Add(this.chkExpression);
            this.tabPage1.Controls.Add(this.lblTypeOfBusiness);
            this.tabPage1.Controls.Add(this.txtTypeOfBusiness);
            this.tabPage1.Controls.Add(this.linkLookup3);
            this.tabPage1.Controls.Add(this.lblSICCode);
            this.tabPage1.Controls.Add(this.txtSICCode);
            this.tabPage1.Controls.Add(this.lblOrgFullDesc);
            this.tabPage1.Controls.Add(this.txtOrgFullDesc);
            this.tabPage1.Controls.Add(this.lblPhoneNumber);
            this.tabPage1.Controls.Add(this.txtPhoneNumber);
            this.tabPage1.Controls.Add(this.lblFax);
            this.tabPage1.Controls.Add(this.txtFax);
            this.tabPage1.Controls.Add(this.lblEmail);
            this.tabPage1.Controls.Add(this.txtEmail);
            this.tabPage1.Controls.Add(this.lblWebAddress);
            this.tabPage1.Controls.Add(this.txtWebAddress);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(812, 452);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Details 1";
            this.tabPage1.UseVisualStyleBackColor = true;

            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(812, 452);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Details 2";
            this.tabPage2.UseVisualStyleBackColor = true;

            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(812, 452);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Details 3";
            this.tabPage3.UseVisualStyleBackColor = true;

            // 
            // lblOrgName
            // 
            this.lblOrgName.AutoSize = true;
            this.lblOrgName.Location = new System.Drawing.Point(30, 30);
            this.lblOrgName.Name = "lblOrgName";
            this.lblOrgName.Size = new System.Drawing.Size(130, 15);
            this.lblOrgName.TabIndex = 0;
            this.lblOrgName.Text = "Organisation Name *";

            // 
            // txtOrgName
            // 
            this.txtOrgName.Location = new System.Drawing.Point(230, 27);
            this.txtOrgName.Name = "txtOrgName";
            this.txtOrgName.Size = new System.Drawing.Size(200, 23);
            this.txtOrgName.TabIndex = 1;

            // 
            // lblOrgShortDesc
            // 
            this.lblOrgShortDesc.AutoSize = true;
            this.lblOrgShortDesc.Location = new System.Drawing.Point(30, 60);
            this.lblOrgShortDesc.Name = "lblOrgShortDesc";
            this.lblOrgShortDesc.Size = new System.Drawing.Size(150, 30);
            this.lblOrgShortDesc.TabIndex = 2;
            this.lblOrgShortDesc.Text = "Organisation Short\r\nDescription *";

            // 
            // txtOrgShortDesc
            // 
            this.txtOrgShortDesc.Location = new System.Drawing.Point(230, 57);
            this.txtOrgShortDesc.Multiline = true;
            this.txtOrgShortDesc.Name = "txtOrgShortDesc";
            this.txtOrgShortDesc.Size = new System.Drawing.Size(200, 50);
            this.txtOrgShortDesc.TabIndex = 3;

            // 
            // lblLeadContact
            // 
            this.lblLeadContact.AutoSize = true;
            this.lblLeadContact.Location = new System.Drawing.Point(30, 120);
            this.lblLeadContact.Name = "lblLeadContact";
            this.lblLeadContact.Size = new System.Drawing.Size(80, 15);
            this.lblLeadContact.TabIndex = 4;
            this.lblLeadContact.Text = "Lead Contact";

            // 
            // txtLeadContact
            // 
            this.txtLeadContact.Location = new System.Drawing.Point(230, 117);
            this.txtLeadContact.Name = "txtLeadContact";
            this.txtLeadContact.Size = new System.Drawing.Size(150, 23);
            this.txtLeadContact.TabIndex = 5;

            // 
            // linkLookup1
            // 
            this.linkLookup1.AutoSize = true;
            this.linkLookup1.Location = new System.Drawing.Point(390, 120);
            this.linkLookup1.Name = "linkLookup1";
            this.linkLookup1.Size = new System.Drawing.Size(46, 15);
            this.linkLookup1.TabIndex = 6;
            this.linkLookup1.TabStop = true;
            this.linkLookup1.Text = "Lookup";

            // 
            // lblAddressLine1
            // 
            this.lblAddressLine1.AutoSize = true;
            this.lblAddressLine1.Location = new System.Drawing.Point(30, 155);
            this.lblAddressLine1.Name = "lblAddressLine1";
            this.lblAddressLine1.Size = new System.Drawing.Size(95, 15);
            this.lblAddressLine1.TabIndex = 7;
            this.lblAddressLine1.Text = "Address Line 1 *";

            // 
            // txtAddressLine1
            // 
            this.txtAddressLine1.Location = new System.Drawing.Point(230, 152);
            this.txtAddressLine1.Name = "txtAddressLine1";
            this.txtAddressLine1.Size = new System.Drawing.Size(200, 23);
            this.txtAddressLine1.TabIndex = 8;

            // 
            // lblAddressLine2
            // 
            this.lblAddressLine2.AutoSize = true;
            this.lblAddressLine2.Location = new System.Drawing.Point(30, 185);
            this.lblAddressLine2.Name = "lblAddressLine2";
            this.lblAddressLine2.Size = new System.Drawing.Size(85, 15);
            this.lblAddressLine2.TabIndex = 9;
            this.lblAddressLine2.Text = "Address Line 2";

            // 
            // txtAddressLine2
            // 
            this.txtAddressLine2.Location = new System.Drawing.Point(230, 182);
            this.txtAddressLine2.Name = "txtAddressLine2";
            this.txtAddressLine2.Size = new System.Drawing.Size(200, 23);
            this.txtAddressLine2.TabIndex = 10;

            // 
            // lblAddressLine3
            // 
            this.lblAddressLine3.AutoSize = true;
            this.lblAddressLine3.Location = new System.Drawing.Point(30, 215);
            this.lblAddressLine3.Name = "lblAddressLine3";
            this.lblAddressLine3.Size = new System.Drawing.Size(85, 15);
            this.lblAddressLine3.TabIndex = 11;
            this.lblAddressLine3.Text = "Address Line 3";

            // 
            // txtAddressLine3
            // 
            this.txtAddressLine3.Location = new System.Drawing.Point(230, 212);
            this.txtAddressLine3.Name = "txtAddressLine3";
            this.txtAddressLine3.Size = new System.Drawing.Size(200, 23);
            this.txtAddressLine3.TabIndex = 12;

            // 
            // lblPostcode
            // 
            this.lblPostcode.AutoSize = true;
            this.lblPostcode.Location = new System.Drawing.Point(30, 245);
            this.lblPostcode.Name = "lblPostcode";
            this.lblPostcode.Size = new System.Drawing.Size(65, 15);
            this.lblPostcode.TabIndex = 13;
            this.lblPostcode.Text = "Postcode *";

            // 
            // txtPostcode
            // 
            this.txtPostcode.Location = new System.Drawing.Point(230, 242);
            this.txtPostcode.Name = "txtPostcode";
            this.txtPostcode.Size = new System.Drawing.Size(120, 23);
            this.txtPostcode.TabIndex = 14;

            // 
            // linkLookup2
            // 
            this.linkLookup2.AutoSize = true;
            this.linkLookup2.Location = new System.Drawing.Point(360, 245);
            this.linkLookup2.Name = "linkLookup2";
            this.linkLookup2.Size = new System.Drawing.Size(46, 15);
            this.linkLookup2.TabIndex = 15;
            this.linkLookup2.TabStop = true;
            this.linkLookup2.Text = "Lookup";

            // 
            // lblCityTown
            // 
            this.lblCityTown.AutoSize = true;
            this.lblCityTown.Location = new System.Drawing.Point(30, 275);
            this.lblCityTown.Name = "lblCityTown";
            this.lblCityTown.Size = new System.Drawing.Size(62, 15);
            this.lblCityTown.TabIndex = 16;
            this.lblCityTown.Text = "City/Town";

            // 
            // txtCityTown
            // 
            this.txtCityTown.Location = new System.Drawing.Point(230, 272);
            this.txtCityTown.Name = "txtCityTown";
            this.txtCityTown.Size = new System.Drawing.Size(200, 23);
            this.txtCityTown.TabIndex = 17;

            // 
            // lblCounty
            // 
            this.lblCounty.AutoSize = true;
            this.lblCounty.Location = new System.Drawing.Point(30, 305);
            this.lblCounty.Name = "lblCounty";
            this.lblCounty.Size = new System.Drawing.Size(48, 15);
            this.lblCounty.TabIndex = 18;
            this.lblCounty.Text = "County";

            // 
            // txtCounty
            // 
            this.txtCounty.Location = new System.Drawing.Point(230, 302);
            this.txtCounty.Name = "txtCounty";
            this.txtCounty.Size = new System.Drawing.Size(200, 23);
            this.txtCounty.TabIndex = 19;

            // 
            // lblPrefOrg
            // 
            this.lblPrefOrg.AutoSize = true;
            this.lblPrefOrg.Location = new System.Drawing.Point(480, 30);
            this.lblPrefOrg.Name = "lblPrefOrg";
            this.lblPrefOrg.Size = new System.Drawing.Size(140, 15);
            this.lblPrefOrg.TabIndex = 20;
            this.lblPrefOrg.Text = "Preferred Organisation";

            // 
            // chkPrefOrg
            // 
            this.chkPrefOrg.AutoSize = true;
            this.chkPrefOrg.Location = new System.Drawing.Point(630, 30);
            this.chkPrefOrg.Name = "chkPrefOrg";
            this.chkPrefOrg.Size = new System.Drawing.Size(15, 14);
            this.chkPrefOrg.TabIndex = 21;
            this.chkPrefOrg.UseVisualStyleBackColor = true;

            // 
            // lblExpression
            // 
            this.lblExpression.AutoSize = true;
            this.lblExpression.Location = new System.Drawing.Point(480, 60);
            this.lblExpression.Name = "lblExpression";
            this.lblExpression.Size = new System.Drawing.Size(130, 15);
            this.lblExpression.TabIndex = 22;
            this.lblExpression.Text = "Expression of Interest";

            // 
            // chkExpression
            // 
            this.chkExpression.AutoSize = true;
            this.chkExpression.Location = new System.Drawing.Point(630, 60);
            this.chkExpression.Name = "chkExpression";
            this.chkExpression.Size = new System.Drawing.Size(15, 14);
            this.chkExpression.TabIndex = 23;
            this.chkExpression.UseVisualStyleBackColor = true;

            // 
            // lblTypeOfBusiness
            // 
            this.lblTypeOfBusiness.AutoSize = true;
            this.lblTypeOfBusiness.Location = new System.Drawing.Point(480, 90);
            this.lblTypeOfBusiness.Name = "lblTypeOfBusiness";
            this.lblTypeOfBusiness.Size = new System.Drawing.Size(110, 15);
            this.lblTypeOfBusiness.TabIndex = 24;
            this.lblTypeOfBusiness.Text = "Type of Business *";

            // 
            // txtTypeOfBusiness
            // 
            this.txtTypeOfBusiness.Location = new System.Drawing.Point(630, 87);
            this.txtTypeOfBusiness.Name = "txtTypeOfBusiness";
            this.txtTypeOfBusiness.Size = new System.Drawing.Size(100, 23);
            this.txtTypeOfBusiness.TabIndex = 25;

            // 
            // linkLookup3
            // 
            this.linkLookup3.AutoSize = true;
            this.linkLookup3.Location = new System.Drawing.Point(740, 90);
            this.linkLookup3.Name = "linkLookup3";
            this.linkLookup3.Size = new System.Drawing.Size(46, 15);
            this.linkLookup3.TabIndex = 26;
            this.linkLookup3.TabStop = true;
            this.linkLookup3.Text = "Lookup";

            // 
            // lblSICCode
            // 
            this.lblSICCode.AutoSize = true;
            this.lblSICCode.Location = new System.Drawing.Point(480, 120);
            this.lblSICCode.Name = "lblSICCode";
            this.lblSICCode.Size = new System.Drawing.Size(60, 15);
            this.lblSICCode.TabIndex = 27;
            this.lblSICCode.Text = "SIC Code";

            // 
            // txtSICCode
            // 
            this.txtSICCode.Location = new System.Drawing.Point(630, 117);
            this.txtSICCode.Name = "txtSICCode";
            this.txtSICCode.Size = new System.Drawing.Size(100, 23);
            this.txtSICCode.TabIndex = 28;

            // 
            // lblOrgFullDesc
            // 
            this.lblOrgFullDesc.AutoSize = true;
            this.lblOrgFullDesc.Location = new System.Drawing.Point(480, 150);
            this.lblOrgFullDesc.Name = "lblOrgFullDesc";
            this.lblOrgFullDesc.Size = new System.Drawing.Size(130, 30);
            this.lblOrgFullDesc.TabIndex = 29;
            this.lblOrgFullDesc.Text = "Organisation Full\r\nDescription";

            // 
            // txtOrgFullDesc
            // 
            this.txtOrgFullDesc.Location = new System.Drawing.Point(630, 147);
            this.txtOrgFullDesc.Multiline = true;
            this.txtOrgFullDesc.Name = "txtOrgFullDesc";
            this.txtOrgFullDesc.Size = new System.Drawing.Size(150, 50);
            this.txtOrgFullDesc.TabIndex = 30;

            // 
            // lblPhoneNumber
            // 
            this.lblPhoneNumber.AutoSize = true;
            this.lblPhoneNumber.Location = new System.Drawing.Point(480, 215);
            this.lblPhoneNumber.Name = "lblPhoneNumber";
            this.lblPhoneNumber.Size = new System.Drawing.Size(100, 15);
            this.lblPhoneNumber.TabIndex = 31;
            this.lblPhoneNumber.Text = "Phone Number *";

            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.Location = new System.Drawing.Point(630, 212);
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(150, 23);
            this.txtPhoneNumber.TabIndex = 32;

            // 
            // lblFax
            // 
            this.lblFax.AutoSize = true;
            this.lblFax.Location = new System.Drawing.Point(480, 245);
            this.lblFax.Name = "lblFax";
            this.lblFax.Size = new System.Drawing.Size(26, 15);
            this.lblFax.TabIndex = 33;
            this.lblFax.Text = "Fax";

            // 
            // txtFax
            // 
            this.txtFax.Location = new System.Drawing.Point(630, 242);
            this.txtFax.Name = "txtFax";
            this.txtFax.Size = new System.Drawing.Size(150, 23);
            this.txtFax.TabIndex = 34;

            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(480, 275);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(36, 15);
            this.lblEmail.TabIndex = 35;
            this.lblEmail.Text = "Email";

            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(630, 272);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(150, 23);
            this.txtEmail.TabIndex = 36;

            // 
            // lblWebAddress
            // 
            this.lblWebAddress.AutoSize = true;
            this.lblWebAddress.Location = new System.Drawing.Point(480, 305);
            this.lblWebAddress.Name = "lblWebAddress";
            this.lblWebAddress.Size = new System.Drawing.Size(78, 15);
            this.lblWebAddress.TabIndex = 37;
            this.lblWebAddress.Text = "Web Address";

            // 
            // txtWebAddress
            // 
            this.txtWebAddress.Location = new System.Drawing.Point(630, 302);
            this.txtWebAddress.Name = "txtWebAddress";
            this.txtWebAddress.Size = new System.Drawing.Size(150, 23);
            this.txtWebAddress.TabIndex = 38;

            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(668, 12);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 39;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;

            // 
            // btnDirector
            // 
            this.btnDirector.Location = new System.Drawing.Point(587, 12);
            this.btnDirector.Name = "btnDirector";
            this.btnDirector.Size = new System.Drawing.Size(75, 23);
            this.btnDirector.TabIndex = 41;
            this.btnDirector.Text = "Director";
            this.btnDirector.UseVisualStyleBackColor = true;
            this.btnDirector.Enabled = false;


            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(749, 12);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 40;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;

            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(844, 533);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnDirector);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Organisation Details";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;

        private System.Windows.Forms.Label lblOrgName;
        private System.Windows.Forms.TextBox txtOrgName;
        private System.Windows.Forms.Label lblOrgShortDesc;
        private System.Windows.Forms.TextBox txtOrgShortDesc;
        private System.Windows.Forms.Label lblLeadContact;
        private System.Windows.Forms.TextBox txtLeadContact;
        private System.Windows.Forms.LinkLabel linkLookup1;
        private System.Windows.Forms.Label lblAddressLine1;
        private System.Windows.Forms.TextBox txtAddressLine1;
        private System.Windows.Forms.Label lblAddressLine2;
        private System.Windows.Forms.TextBox txtAddressLine2;
        private System.Windows.Forms.Label lblAddressLine3;
        private System.Windows.Forms.TextBox txtAddressLine3;
        private System.Windows.Forms.Label lblPostcode;
        private System.Windows.Forms.TextBox txtPostcode;
        private System.Windows.Forms.LinkLabel linkLookup2;
        private System.Windows.Forms.Label lblCityTown;
        private System.Windows.Forms.TextBox txtCityTown;
        private System.Windows.Forms.Label lblCounty;
        private System.Windows.Forms.TextBox txtCounty;

        private System.Windows.Forms.Label lblPrefOrg;
        private System.Windows.Forms.CheckBox chkPrefOrg;
        private System.Windows.Forms.Label lblExpression;
        private System.Windows.Forms.CheckBox chkExpression;
        private System.Windows.Forms.Label lblTypeOfBusiness;
        private System.Windows.Forms.TextBox txtTypeOfBusiness;
        private System.Windows.Forms.LinkLabel linkLookup3;
        private System.Windows.Forms.Label lblSICCode;
        private System.Windows.Forms.TextBox txtSICCode;
        private System.Windows.Forms.Label lblOrgFullDesc;
        private System.Windows.Forms.TextBox txtOrgFullDesc;
        private System.Windows.Forms.Label lblPhoneNumber;
        private System.Windows.Forms.TextBox txtPhoneNumber;
        private System.Windows.Forms.Label lblFax;
        private System.Windows.Forms.TextBox txtFax;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblWebAddress;
        private System.Windows.Forms.TextBox txtWebAddress;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDirector;
        private System.Windows.Forms.Button btnBack;
    }
}