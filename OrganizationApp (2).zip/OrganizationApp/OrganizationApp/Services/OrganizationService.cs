﻿using System;
using System.Text.RegularExpressions;
using Npgsql;
using OrganizationApp.Models;

namespace OrganizationApp.Services
{
    public class OrganizationService
    {
        private readonly string _connectionString =
            "Host=localhost;Port=5432;Database=organization_db;Username=postgres;Password=123";

        public int Save(Organization org)
        {
            Validate(org);

            using (var conn = new NpgsqlConnection(_connectionString))
            {
                conn.Open();

                using (var checkCmd = new NpgsqlCommand(
                    "SELECT COUNT(*) FROM ORGANIZATION WHERE LOWER(OrgName)=LOWER(@name)", conn))
                {
                    checkCmd.Parameters.AddWithValue("@name", org.OrgName);
                    if ((long)checkCmd.ExecuteScalar() > 0)
                        throw new ArgumentException("Organization Name already exists");
                }

                using (var cmd = new NpgsqlCommand(
                    @"INSERT INTO ORGANIZATION (OrgName, Address, Phone, Email)
                      VALUES (@n,@a,@p,@e)
                      RETURNING OrgID", conn))
                {
                    cmd.Parameters.AddWithValue("@n", org.OrgName);
                    cmd.Parameters.AddWithValue("@a", (object)org.Address ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@p", (object)org.Phone ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@e", (object)org.Email ?? DBNull.Value);

                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        public void Validate(Organization org)
        {
            if (string.IsNullOrWhiteSpace(org.OrgName))
                throw new ArgumentException("Organization Name is required");

            if (org.OrgName.Length < 3 || org.OrgName.Length > 255)
                throw new ArgumentException("Organization Name length must be 3–255");

            if (!string.IsNullOrEmpty(org.Email))
            {
                if (!Regex.IsMatch(org.Email,
                    @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                    throw new ArgumentException("Invalid Email format");
            }

            if (!string.IsNullOrEmpty(org.Phone))
            {
                if (!Regex.IsMatch(org.Phone, @"^\d{9,12}$"))
                    throw new ArgumentException("Phone must be 9–12 digits");
            }
        }
    }
}
