﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace PowerUnitTest
{
    [TestClass]
    public class PowerTests
    {
        static double Power(double x, int n)
        {
            if (n == 0)
                return 1.0;
            else if (n > 0)
                return x * Power(x, n - 1);
            else
                return Power(x, n + 1) / x;
        }


        [TestMethod]
        public void TC01_N_Bang_0()
        {
            Assert.AreEqual(1.0, Power(10, 0));
        }

        [TestMethod]
        public void TC02_N_Duong()
        {
            Assert.AreEqual(8.0, Power(2, 3));
            Assert.AreEqual(25.0, Power(5, 2));
        }

        [TestMethod]
        public void TC03_N_Am()
        {
            Assert.AreEqual(0.5, Power(2, -1), 1e-9);
            Assert.AreEqual(0.25, Power(2, -2), 1e-9);
        }

        [TestMethod]
        public void TC04_Co_So_Am()
        {
            Assert.AreEqual(-8.0, Power(-2, 3), 1e-9);
            Assert.AreEqual(4.0, Power(-2, 2), 1e-9);
        }

        [TestMethod]
        public void TC05_Co_So_Bang_1()
        {
            Assert.AreEqual(1.0, Power(1, 50), 1e-9);
            Assert.AreEqual(1.0, Power(1, -50), 1e-9);
        }
    }
}
