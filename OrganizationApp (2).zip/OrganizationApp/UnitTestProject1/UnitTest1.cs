﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrganizationApp.Models;
using OrganizationApp.Services;
using System;

namespace UnitTestProject1
{
    [TestClass]
    public class OrganizationServiceTests
    {
        private OrganizationService _service;

        [TestInitialize]
        public void Setup()
        {
            _service = new OrganizationService();
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Save_ShouldThrow_WhenOrgNameIsNull()
        {
            _service.Save(new Organization
            {
                OrgName = null,
                Phone = "0984238534"
            });
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Save_ShouldThrow_WhenOrgNameIsEmpty()
        {
            _service.Save(new Organization
            {
                OrgName = "",
                Phone = "0984238534"
            });
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Save_ShouldThrow_WhenOrgNameTooShort()
        {
            _service.Save(new Organization
            {
                OrgName = "AB",
                Phone = "0984238534"
            });
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Save_ShouldThrow_WhenOrgNameTooLong()
        {
            _service.Save(new Organization
            {
                OrgName = new string('A', 300),
                Phone = "0984238534"
            });
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Save_ShouldThrow_WhenEmailInvalid()
        {
            _service.Save(new Organization
            {
                OrgName = "Email Invalid " + Guid.NewGuid(),
                Phone = "0984238534",
                Email = "sai-email"
            });
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Save_ShouldThrow_WhenPhoneContainsLetters()
        {
            _service.Save(new Organization
            {
                OrgName = "Phone Invalid " + Guid.NewGuid(),
                Phone = "09ABC123"
            });
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Save_ShouldThrow_WhenPhoneTooShort()
        {
            _service.Save(new Organization
            {
                OrgName = "Phone Short " + Guid.NewGuid(),
                Phone = "12345"
            });
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Save_ShouldThrow_WhenPhoneTooLong()
        {
            _service.Save(new Organization
            {
                OrgName = "Phone Long " + Guid.NewGuid(),
                Phone = "01234567890123"
            });
        }

        [TestMethod]
        public void Save_ShouldSuccess_WhenEmailIsNull()
        {
            int id = _service.Save(new Organization
            {
                OrgName = "No Email " + Guid.NewGuid(),
                Phone = "0984238534"
            });

            Assert.IsTrue(id > 0);
        }

        [TestMethod]
        public void Save_ShouldSuccess_WhenPhoneIsNull()
        {
            int id = _service.Save(new Organization
            {
                OrgName = "No Phone " + Guid.NewGuid(),
                Email = "anguyen@gmail.com"
            });

            Assert.IsTrue(id > 0);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void Save_ShouldThrow_WhenOrgNameDuplicate_CaseInsensitive()
        {
            string name = "Duplicate Org " + Guid.NewGuid();

            _service.Save(new Organization
            {
                OrgName = name,
                Phone = "0984238534"
            });

            _service.Save(new Organization
            {
                OrgName = name.ToUpper(),
                Phone = "0984238534"
            });
        }

        [TestMethod]
        public void Save_ShouldSuccess_WhenAddressIsNull()
        {
            int id = _service.Save(new Organization
            {
                OrgName = "No Address " + Guid.NewGuid(),
                Phone = "0984238534"
            });

            Assert.IsTrue(id > 0);
        }

        [TestMethod]
        public void Save_ShouldSuccess_WhenEmailValid()
        {
            int id = _service.Save(new Organization
            {
                OrgName = "Valid Email " + Guid.NewGuid(),
                Phone = "0984238534",
                Email = "anguyen@gmail.com"
            });

            Assert.IsTrue(id > 0);
        }

        [TestMethod]
        public void Save_ShouldSuccess_WhenPhoneHas9Digits()
        {
            int id = _service.Save(new Organization
            {
                OrgName = "Phone 9 Digits " + Guid.NewGuid(),
                Phone = "123456789"
            });

            Assert.IsTrue(id > 0);
        }

        [TestMethod]
        public void Save_ShouldSuccess_WhenAllDataValid()
        {
            int id = _service.Save(new Organization
            {
                OrgName = "Công ty Bình An " + Guid.NewGuid(),
                Address = "TP Hồ Chí Minh",
                Phone = "09842385345",
                Email = "anguyen@gmail.com"
            });

            Assert.IsTrue(id > 0);
        }
    }
}
